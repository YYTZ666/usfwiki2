# 版本对应表
使用非最新版时请前往对应版本页面查看，部分版本可能会有特殊说明

兼容表(此处所指的游戏版本均为正式版)：
V2:
0.6.34  for Minecraft1.21.50+
0.6.33  for Minecraft1.21.40+  
0.6.32 for Minecraft1.21.30+  
0.6.31 for Minecraft1.21.31  
0.6.30 For Minecraft1.21.20  
0.6.29同0.6.23  
0.6.28同0.6.23  
0.6.27同0.6.23  
0.6.26同0.6.23  
0.6.25同0.6.23  
0.6.24同0.6.23  
0.6.23 For Minecraft1.21.0 and Minecraft1.21.1 and Minecraft1.21.2  
0.6.22 For Minecraft1.21.0 and Minecraft1.21.1 and Minecraft1.21.2  
0.6.21 For Minecraft1.21.0 and Minecraft1.21.1 and Minecraft1.21.2  
0.6.19 For Minecraft1.21.0 and Minecraft1.21.1
0.6.18 For Minecraft1.20.8x  
0.6.17 For Minecraft1.20.50/51 and Minecraft1.20.60  
0.6.16 For Minecraft1.20.50/51 and Minecraft1.20.60
0.6.15 For Minecraft1.20.50/51 and Minecraft1.20.60  
0.6.14 For Minecraft1.20.50/51 and Minecraft1.20.60  
0.6.13 For Minecraft1.20.50/51 and Minecraft1.20.60  
0.6.12 For Minecraft1.20.50/51  
0.6.11 For Minecraft1.20.50/51  
0.6.10 For Minecraft1.20.50/51  

V1:
0.6.16 For Minecraft1.20.60  
0.6.14 For Minecraft1.20.60  
0.6.8 For Minecraft1.20.50/51  
0.6.7 For Minecraft1.20.40.23  
0.6.6 For Minecraft1.20.30  
0.6.5 For Minecraft1.20.30  
0.6.4 For Minecraft1.20.10/11/12  
0.6.3 For Minecraft1.20.10/11/12  
0.6.2 For Minecraft1.20.10.23/24/25(测试版)  
0.6.1 For Minecraft1.20.10.21/22(测试版)  
0.6.0 For Minecraft1.20.10.21/22(测试版)  
0.5.5 For Minecraft1.19.8x  
0.5.4 For Minecraft1.19.7x  
0.5.3 For Minecraft1.19.7x  
0.5.2 For Minecraft1.19.7x  
0.5.1 For Minecraft1.19.7x  
0.4.1/0.4.2 For Minecraft1.19.6x  
0.0.2/0.0.3/0.3.x For Minecraft1.19.5x  