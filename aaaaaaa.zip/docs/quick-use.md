# 快速上手
『无名氏服务器插件』是一个基于原版GameTest框架的插件，让原生BDS也可以拥有很多基础的功能。
目前下载量已超过3w，期待你的使用
![image](upload/202402/202402080826570.png)

## 适用范围
- Minecraft基岩版存档
- Realm
- BDS(LLSE)

## 前置插件
- NodeJS(For日志系统)

## 支持语言
简体中文(Zh-CN)
翻译体英语(En-Translate)

## 官方(宣传)帖
[MineBBS官方帖](https://www.minebbs.com/resources/usf.5475/)

## 关于
插件作者：EarthDLL(E-Mail：earthdll@outlook.com)

管理员：qcbby，悠米看悠米

插件名：无名氏牌服务器插件(Unkown Server FrameWork)

官方交流群：107403959

文档发起人：YYTZ
文档贡献者：YYTZ，EarthDLL，qcbby，MengZe2l，dyf189  
文档维护管理：qcbby，MengZe2l，MengZe2l

## 版权说明
在不侵犯作者版权情况下，可自行修改、分发、二次修改、二次分发。禁止以付费形式传播本插件主体部分(包含日志)
最终解释权归USF团队