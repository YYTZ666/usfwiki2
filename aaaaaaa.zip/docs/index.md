---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "USF V2"
  text: "基于原版SAPI的无名氏服务器管理框架"
  tagline: 高性能的Minecraft服务器管理框架
  actions:
    - theme: brand
      text: 快速使用
      link: /quick-use
    - theme: alt
      text: 下载
      link: https://usfdown.zuyst.top/

features:
  - icon: "💻"
    title: 基于原版 高可用性
    details: 完全使用基岩版原版的Script API开发，无任何其他依赖。
  - icon: "📦"
    title: 高度优化 极致流畅
    details: 几乎不会对服务器和客户端带来然后压力，代码也是高度优化绝无屎删
  - icon: "🛠️"
    title: 使用简单 功能方法
    details: 使用起来非常简单顺手，功能特别多，高度支持自定义化
---

